"""
Wheeler–Feynman absorber-theory handshake on S³.

Retarded offer → advanced confirm → phase-closure transaction.
Implements the full amplitude algebra: hit envelope, antipodal match,
mode overlap, SU(2) spin phase, and time-symmetric phase closure.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

from geometrodynamics.constants import (
    EPS_HIT,
    SIGMA_ANTI,
    OFFER_TTL,
    CONFIRM_TTL,
    PHASE_MATCH_SIGMA,
)
from geometrodynamics.transaction.s3_geometry import geo4, antipode4
from geometrodynamics.transaction.particles import MouthState, Particle4


# ── Helper functions ─────────────────────────────────────────────────────────

def gw_hit_envelope(psi_diff: float, eps_hit: float = EPS_HIT) -> float:
    """Gaussian hit envelope for GW shell / particle overlap."""
    return float(np.exp(-(psi_diff ** 2) / (2.0 * eps_hit ** 2)))


def antipodal_match_weight(c_p4, d_p4, sigma: float = SIGMA_ANTI) -> float:
    """How close candidate and destination are to being antipodal."""
    anti_err = geo4(c_p4, antipode4(d_p4))
    return float(np.exp(-(anti_err ** 2) / (2.0 * sigma ** 2)))


def complex_mode_overlap(mouth_c: MouthState, mouth_d: MouthState) -> complex:
    """Normalised complex inner product of two mouths' mode spectra."""
    keys = set(mouth_c.modes).intersection(mouth_d.modes)
    if not keys:
        return 0.0 + 0.0j
    num = 0.0 + 0.0j
    den_c = den_d = 0.0
    for k in keys:
        ac = mouth_c.modes[k].complex_amplitude()
        ad = mouth_d.modes[k].complex_amplitude()
        num += np.conj(ac) * ad
        den_c += abs(ac) ** 2
        den_d += abs(ad) ** 2
    if den_c <= 1e-18 or den_d <= 1e-18:
        return 0.0 + 0.0j
    return num / np.sqrt(den_c * den_d)


def mode_overlap(mouth_c: MouthState, mouth_d: MouthState) -> float:
    return float(abs(complex_mode_overlap(mouth_c, mouth_d)))


def su2_spin_phase(
    theta_transport: float,
    mouth_c: Optional[MouthState] = None,
    mouth_d: Optional[MouthState] = None,
    alpha_spin: float = 0.5,
) -> complex:
    """SU(2) spin phase from geodesic transport + relative mouth phase."""
    rel_phase = 0.0
    if mouth_c is not None and mouth_d is not None:
        coh = complex_mode_overlap(mouth_c, mouth_d)
        if abs(coh) > 1e-18:
            rel_phase = float(np.angle(coh))
        else:
            rel_phase = mouth_d.mean_phase() - mouth_c.mean_phase()
    return complex(np.exp(1j * (alpha_spin * theta_transport + 0.5 * rel_phase)))


def wrap_phase(phi: float) -> float:
    return float((phi + np.pi) % (2.0 * np.pi) - np.pi)


def mouth_activity(mouth: MouthState) -> float:
    """RMS amplitude of all active throat modes."""
    if not mouth.modes:
        return 0.0
    total = 0.0
    for m in mouth.modes.values():
        scale = max(m.omega, 1e-9)
        total += m.a ** 2 + (m.adot / scale) ** 2
    return float(np.sqrt(max(total, 0.0)))


# ── Signal dataclasses ───────────────────────────────────────────────────────

@dataclass
class OfferSignal:
    """Retarded offer from source, via candidate, toward absorber."""

    grav_id: int
    src_pid: int
    cand_pid: int
    t_birth: float
    hit_weight: float
    theta_src_cand: float
    response: float
    amp: complex
    geom_phase: float = 0.0
    ttl: float = OFFER_TTL

    def is_alive(self, t_now: float) -> bool:
        return (t_now - self.t_birth) <= self.ttl and abs(self.amp) > 1e-12


@dataclass
class Transaction:
    """Confirmed handshake: offer + confirm amplitudes pass phase closure."""

    grav_id: int
    src_pid: int
    cand_pid: int
    dst_pid: int
    t_birth: float
    amp: complex
    offer_amp: complex
    confirm_amp: complex
    q_src: float
    q_dst: float
    field_at_dst: float
    overlap: float
    anti_weight: float
    spin_phase: float
    hit_weight: float
    pair_kernel: float
    phase_mismatch: float
    phase_match_weight: float
    is_confirmed: bool = True
    ttl: float = CONFIRM_TTL

    def is_alive(self, t_now: float) -> bool:
        return (
            self.is_confirmed
            and (t_now - self.t_birth) <= self.ttl
            and abs(self.amp) > 1e-12
        )


# ── Amplitude constructors ───────────────────────────────────────────────────

def retarded_offer_amplitude(
    src: Particle4,
    cand: Particle4,
    hit_weight: float,
    gw_radius: float,
) -> tuple[complex, float, float, float]:
    """Compute retarded offer amplitude from source through candidate."""
    theta_src_cand = geo4(src.p4, cand.p4)
    response = mouth_activity(cand.mouth)
    response = max(response, 0.10 * hit_weight)
    geom_phase = 0.5 * (gw_radius + theta_src_cand)
    phase = geom_phase + cand.mouth.mean_phase()
    amp = hit_weight * response * np.exp(1j * phase)
    return complex(amp), theta_src_cand, float(response), float(geom_phase)


def advanced_confirm_amplitude(
    cand: Particle4,
    dst: Particle4,
    dst_field_sol: Optional[dict],
) -> tuple[complex, float, float, float, float, float]:
    """Advanced (time-reversed) confirmation from absorber dst."""
    anti_w = antipodal_match_weight(cand.p4, dst.p4)
    coh = complex_mode_overlap(cand.mouth, dst.mouth)
    overlap = float(abs(coh))
    theta_cand_dst = geo4(cand.p4, dst.p4)
    spin_phase = su2_spin_phase(theta_cand_dst, cand.mouth, dst.mouth)

    if dst_field_sol is not None:
        field_at_dst = float(
            np.interp(1.08, dst_field_sol["r"], dst_field_sol["E_r"])
        )
    else:
        field_at_dst = float(mouth_activity(dst.mouth)) + 1e-6

    adv_phase = np.conj(spin_phase) * np.exp(
        -1j * (0.5 * theta_cand_dst + dst.mouth.mean_phase())
    )
    amp = anti_w * overlap * field_at_dst * adv_phase
    return (
        complex(amp),
        anti_w,
        overlap,
        field_at_dst,
        float(np.angle(spin_phase)),
        theta_cand_dst,
    )


def retro_phase_match(
    offer_amp: complex,
    confirm_amp: complex,
    sigma: float = PHASE_MATCH_SIGMA,
) -> tuple[float, float]:
    """Time-symmetric phase closure scoring both 0 and π branches."""
    total = wrap_phase(np.angle(offer_amp) + np.angle(confirm_amp))
    mismatch_0 = abs(total)
    mismatch_pi = abs(wrap_phase(total - np.pi))
    mismatch = min(mismatch_0, mismatch_pi)
    weight = float(np.exp(-(mismatch ** 2) / (2.0 * sigma ** 2)))
    return mismatch, weight
