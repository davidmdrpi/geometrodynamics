"""
Geometrodynamics
================

A computational framework for deriving quantum field theory structures
(QED charge, spin-½, Coulomb law; QCD confinement, string breaking)
from pure spacetime geometry.

Subpackages
-----------
hopf          Hopf fibration on S³: connection, curvature, Chern number, spinors
tangherlini   5D wormhole eigenmodes, Maxwell solver, throat flux ratios
transaction   Retrocausal Wheeler–Feynman handshake protocol on S³
qcd           QCD flux-tube network: topology, Störmer–Verlet solver, diagnostics
viz           Visualisation helpers (animation, plotting)
"""

__version__ = "0.40.1"
