"""Tests for the Wheeler–Feynman transaction protocol on S³."""

import numpy as np
import pytest

from geometrodynamics.transaction.s3_geometry import (
    nrm4,
    antipode4,
    geo4,
    hsp,
    s3_green_potential,
    s3_green_field_kernel,
    s3_tangent_direction,
)
from geometrodynamics.transaction.particles import (
    ThroatMode,
    MouthState,
    Particle4,
    GravWave,
)
from geometrodynamics.transaction.handshake import (
    gw_hit_envelope,
    antipodal_match_weight,
    complex_mode_overlap,
    mode_overlap,
    su2_spin_phase,
    wrap_phase,
    mouth_activity,
    retarded_offer_amplitude,
    advanced_confirm_amplitude,
    retro_phase_match,
)


class TestS3Geometry:
    def test_nrm4_unit_length(self):
        v = nrm4([1, 2, 3, 4])
        assert abs(np.linalg.norm(v) - 1.0) < 1e-14

    def test_nrm4_rejects_zero(self):
        with pytest.raises(ValueError):
            nrm4([0, 0, 0, 0])

    def test_antipode_is_negation(self):
        p = np.array([1.0, 0.0, 0.0, 0.0])
        ap = antipode4(p)
        np.testing.assert_allclose(ap, -p)

    def test_geodesic_self_distance_zero(self):
        p = nrm4([1, 0, 0, 0])
        assert abs(geo4(p, p)) < 1e-14

    def test_geodesic_antipodal_distance_pi(self):
        p = nrm4([1, 0, 0, 0])
        assert abs(geo4(p, antipode4(p)) - np.pi) < 1e-10

    def test_hsp_unit_length(self):
        """Hopf-sphere parameterisation gives unit 4-vectors."""
        v = hsp(np.pi / 3, np.pi / 4, np.pi / 6)
        assert abs(np.linalg.norm(v) - 1.0) < 1e-14

    def test_green_potential_symmetry(self):
        """G(ψ) should be symmetric about ψ = π/2 (up to sign convention)."""
        g1 = s3_green_potential(0.5)
        g2 = s3_green_potential(np.pi - 0.5)
        # Both should be finite and of similar magnitude
        assert np.isfinite(g1)
        assert np.isfinite(g2)

    def test_green_potential_diverges_near_source(self):
        """Green function should be large near ψ = 0."""
        g_near = abs(s3_green_potential(0.1))
        g_far = abs(s3_green_potential(1.5))
        assert g_near > g_far

    def test_tangent_direction_orthogonal(self):
        """Tangent vector should be orthogonal to source point."""
        src = nrm4([1, 0, 0, 0])
        dst = nrm4([0, 1, 0, 0])
        tang = s3_tangent_direction(src, dst)
        assert abs(np.dot(src, tang)) < 1e-12


class TestParticles:
    def test_throat_mode_step(self):
        """ThroatMode oscillates under zero drive."""
        mode = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=1.0)
        for _ in range(100):
            mode.step(drive=0.0, dt=0.01)
        # Should oscillate, not diverge
        assert abs(mode.a) < 2.0

    def test_mouth_state_charge_sign(self):
        """Opposite orientation_sign gives opposite charge."""
        m1 = MouthState(orientation_sign=+1)
        m2 = MouthState(orientation_sign=-1)
        mode1 = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=0.5)
        mode2 = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=0.5)
        m1.modes[(1, 0)] = mode1
        m2.modes[(1, 0)] = mode2
        assert m1.q_geom() == -m2.q_geom()

    def test_grav_wave_propagation(self):
        """GW shell expands and terminates at radius π."""
        gw = GravWave(gid=0, src_pid=0, p0=np.array([1, 0, 0, 0]), t_emit=0.0)
        gw.step(t=100.0, c_gw=0.5)
        assert gw.done
        assert gw.radius == np.pi


class TestHandshake:
    def test_hit_envelope_peak(self):
        """Hit envelope peaks at ψ_diff = 0."""
        assert abs(gw_hit_envelope(0.0) - 1.0) < 1e-14

    def test_hit_envelope_decay(self):
        """Hit envelope decays away from zero."""
        assert gw_hit_envelope(1.0) < gw_hit_envelope(0.1) < 1.0

    def test_antipodal_match_exact(self):
        """Exact antipodal pair gets weight ≈ 1."""
        p = nrm4([1, 0, 0, 0])
        w = antipodal_match_weight(p, antipode4(p))
        assert w > 0.99

    def test_antipodal_match_non_antipodal(self):
        """Non-antipodal pair gets lower weight."""
        p1 = nrm4([1, 0, 0, 0])
        p2 = nrm4([0, 1, 0, 0])  # 90° apart, not antipodal
        w = antipodal_match_weight(p1, p2)
        assert w < 0.5

    def test_mode_overlap_identical(self):
        """Identical mouth spectra have overlap 1."""
        m1 = MouthState(orientation_sign=+1)
        m2 = MouthState(orientation_sign=-1)
        mode1 = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=1.0, phase=0.0)
        mode2 = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=1.0, phase=0.0)
        m1.modes[(1, 0)] = mode1
        m2.modes[(1, 0)] = mode2
        assert abs(mode_overlap(m1, m2) - 1.0) < 1e-10

    def test_mode_overlap_empty(self):
        """Empty mouth spectra have zero overlap."""
        m1 = MouthState(orientation_sign=+1)
        m2 = MouthState(orientation_sign=-1)
        assert mode_overlap(m1, m2) == 0.0

    def test_su2_spin_phase_is_unit(self):
        """SU(2) spin phase has unit modulus."""
        phase = su2_spin_phase(np.pi / 3)
        assert abs(abs(phase) - 1.0) < 1e-14

    def test_wrap_phase_range(self):
        """wrap_phase maps to (−π, π]."""
        for val in [0, np.pi, -np.pi, 3 * np.pi, -5.5]:
            w = wrap_phase(val)
            assert -np.pi <= w <= np.pi

    def test_mouth_activity_zero_for_empty(self):
        m = MouthState(orientation_sign=+1)
        assert mouth_activity(m) == 0.0

    def test_mouth_activity_nonzero_for_active(self):
        m = MouthState(orientation_sign=+1)
        m.modes[(1, 0)] = ThroatMode(l=1, n=0, omega=1.0, alpha_q=1.0, a=0.5)
        assert mouth_activity(m) > 0.0

    def test_phase_match_perfect_closure(self):
        """Zero total phase gives mismatch ≈ 0 and weight ≈ 1."""
        offer = complex(np.exp(1j * 0.3))
        confirm = complex(np.exp(-1j * 0.3))
        mismatch, weight = retro_phase_match(offer, confirm)
        assert mismatch < 0.01
        assert weight > 0.99

    def test_phase_match_pi_branch(self):
        """Phase sum ≈ π also closes (Möbius/spinor branch)."""
        offer = complex(np.exp(1j * 0.5))
        confirm = complex(np.exp(1j * (np.pi - 0.5)))
        mismatch, weight = retro_phase_match(offer, confirm)
        assert mismatch < 0.01
        assert weight > 0.99

    def test_end_to_end_offer_confirm(self):
        """Minimal end-to-end: offer from source, confirm from absorber."""
        # Source particle at north pole of S³
        src_mouth = MouthState(orientation_sign=+1)
        src_mouth.modes[(1, 0)] = ThroatMode(
            l=1, n=0, omega=1.0, alpha_q=1.0, a=0.5, adot=0.1,
        )
        src = Particle4(pid=0, p4=nrm4([1, 0, 0, 0]), mouth=src_mouth)

        # Candidate near equator
        cand_mouth = MouthState(orientation_sign=+1)
        cand_mouth.modes[(1, 0)] = ThroatMode(
            l=1, n=0, omega=1.0, alpha_q=1.0, a=0.3, adot=0.05,
        )
        cand = Particle4(pid=1, p4=nrm4([0, 1, 0, 0]), mouth=cand_mouth)

        # Absorber near antipode of source
        dst_mouth = MouthState(orientation_sign=-1)
        dst_mouth.modes[(1, 0)] = ThroatMode(
            l=1, n=0, omega=1.0, alpha_q=1.0, a=0.4, adot=-0.08,
        )
        dst = Particle4(pid=2, p4=nrm4([-1, 0.01, 0, 0]), mouth=dst_mouth)

        # Offer
        offer_amp, theta_sc, response, geom_phase = retarded_offer_amplitude(
            src, cand, hit_weight=0.9, gw_radius=1.5,
        )
        assert abs(offer_amp) > 0
        assert np.isfinite(offer_amp)

        # Confirm
        confirm_amp, anti_w, overlap, field, spin_ang, theta_cd = (
            advanced_confirm_amplitude(cand, dst, dst_field_sol=None)
        )
        assert np.isfinite(confirm_amp)
        assert anti_w > 0  # near-antipodal should have some weight

        # Phase closure
        mismatch, weight = retro_phase_match(offer_amp, confirm_amp)
        assert np.isfinite(mismatch)
        assert 0 <= weight <= 1.0
