"""
Geometrodynamics
================

A research framework implementing and testing Wheeler's geometrodynamic
program: exploring whether QED structures (charge, spin-½, Coulomb law)
and QCD structures (confinement, string breaking) can emerge from pure
spacetime geometry.

Subpackages
-----------
hopf          Hopf fibration on S³: connection, curvature, Chern number, spinors
tangherlini   5D wormhole eigenmodes, Maxwell solver, throat flux ratios
transaction   Retrocausal Wheeler–Feynman handshake protocol on S³
qcd           QCD flux-tube network: topology, Störmer–Verlet solver, diagnostics
viz           Visualisation helpers (animation, plotting)
"""

__version__ = "0.40.3"
